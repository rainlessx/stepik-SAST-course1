# Лаба 5. Триаж находок

Сканер не отличает настоящую уязвимость от безопасного кода, который похож на уязвимость. Прогоните все сканеры и разберите 10 находок: какие реальны, а какие — ложные срабатывания.

## Запуск

make scan


Запустятся все сканеры (Semgrep, OpenGrep, Bandit, SpotBugs+FindSecBugs); 

Ниже 10 находок из этого прогона. Находите каждую по правилу + файлу + функции, открывайте код и решайте, настоящая ли это уязвимость.

Подсказка: Для того чтобы понять настоящая ли это уязвимость, вам нужно понять что делает этот код, если у вас есть знание языка - отлично!
Если пока нет - то можете использовать ИИ для помощи в триаже.

| № | Инструмент / правило | Файл | Функция

| 1 | FindSecBugs `PREDICTABLE_RANDOM` | `PasswordResetService.java` | `createToken`
| 2 | Bandit `B324` | `media.py` | `product_image`
| 3 | Bandit `B608` | `catalog.py` | `search` 
| 4 | FindSecBugs `SQL_INJECTION_SPRING_JDBC` | `OrderRepository.java` | `findById`
| 5 | Bandit `B301` | `cart.py` | `load_cart` 
| 6 | Semgrep `documentbuilderfactory-disallow-doctype-decl-missing` | `PriceListService.java` | `importPriceList`
| 7 | FindSecBugs `PREDICTABLE_RANDOM` | `RecommendationService.java` | `recommend` 
| 8 | Bandit `B324` | `auth.py` | `_hash_password`
| 9 | Bandit `B602` | `media.py` | `cleanup_temp_files`
| 10 | Semgrep `spring-sqli` | `OrderRepository.java` | `searchByCustomer`



## Вопросы (ответы вводятся на Stepik)

1. Сколько из 10 находок — настоящие уязвимости? (число)
2. Сколько из 10 находок — ложные срабатывания (ловушки)? (число)
3. Находка №4 (`findById`) — ложное срабатывание. Почему? (выбор одного варианта — на Stepik)

