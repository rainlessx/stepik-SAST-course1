Надеюсь вы не забыли вернуться на main ветку гит после 6 лабы, (git checkout main)?


# Лаба 7. Свое правило Semgrep для внутреннего стока

В модуле отчетов витрины (app/storefront/storefront/reports.py) есть внутренняя
обертка:

python
def run_report(sql):
    db = get_db()
    with db.cursor() as cur:
        cur.execute(sql)
        return cur.fetchall()


Она выполняет готовую строку SQL. Встроенные правила Semgrep ее не отслеживают: они знают про cursor.execute, но не про вашу функцию-обертку. В модуле есть вызовы run_report(...) — часть с константным SQL (безопасны), часть собирает SQL из ввода пользователя (уязвимы). Напишите свое правило, которое помечает опасные вызовы и не трогает безопасные.

## Задача

Напишите в файл labs/lab07-custom-rule/rule.yaml (рядом с этим README), правило Semgrep, которое:

- срабатывает на run_report(...), когда аргумент — собранная строка (f-строка,   конкатенация, .format, %);
- не срабатывает, когда аргумент — цельный строковый литерал (константа).

Каркас правила:

yaml
rules:
  - id: run-report-dynamic-sql
    languages: [python]
    severity: WARNING
    message: ...
    patterns:
      - pattern: run_report(...)
      # исключите безопасную форму (подумайте, как выглядит константный вызов)


## Проверка локально

Прогоните свое правило по модулю отчетов и посмотрите, какие вызовы оно ловит:

Из корня репозитория:

docker run --rm -v "$PWD:/src:ro" semgrep/semgrep:1.181.0 \
  semgrep scan --metrics=off --disable-version-check \
  --config /src/labs/lab07-custom-rule/rule.yaml /src/app/storefront/storefront/reports.py


Безопасные вызовы (top_selling_products, low_stock_products) помечаться не должны;
вызовы с пользовательским вводом (sales_by_category, revenue_since) — должны.

## Проверка чекером (скрытый набор)

Когда правило готово, загрузите образ чекера (один раз) и прогоните его — чекер применит правило к скрытому набору вызовов и проверит точность:

docker load -i images/checkers.tar
docker run --rm -v "$PWD/labs/lab07-custom-rule/rule.yaml:/rule.yaml:ro" homeshop/lab07-checker:1


Если правило классифицирует весь скрытый набор верно, чекер напечатает токен.

## Вопросы (ответы вводятся на Stepik)

1. Вставьте токен, который напечатал чекер при успешной проверке.
2. Почему встроенные правила Semgrep не находят эти вызовы?

