# Лаба 8. Taint-правило Semgrep для внутреннего стока

В бэкофисе есть обертка над legacy-источником данных:

java
public List<Map<String, Object>> exec(String sql) {
    return jdbc.queryForList(sql);
}

(app/backoffice/src/main/java/com/homeshop/backoffice/legacy/LegacyQuery.java)

Методы отчетов строят строку SQL и передают ее в legacyQuery.exec(...). В одних значение приходит из параметра запроса (уязвимо), в других — это константа (безопасно). Простого шаблона мало: exec(...) вызывается и в безопасных местах.
Нужно правило в режиме taint — оно пометит вызов только если в него дотекает пользовательский ввод.

## Задача

Напишите правило в файл labs/lab08-taint-rule/rule.yaml (рядом с этим README), c mode: taint:

- источник (pattern-sources) — чтение параметра запроса
  ($R.getParameter(...));
- сток (pattern-sinks) — вызов $Q.exec(...).

Правило срабатывает, когда значение из источника доходит до стока.

Каркас:

yaml
rules:
  - id: legacyquery-tainted-sql
    languages: [java]
    severity: WARNING
    message: ...
    mode: taint
    pattern-sources:
      - pattern: ...
    pattern-sinks:
      - pattern: ...


## Проверка локально

В папке лабы есть тренировочный файл practice.java с двумя методами
(уязвимый и безопасный). Прогоните по нему свое правило:

Из корня репозитория:

docker run --rm -v "$PWD:/src:ro" semgrep/semgrep:1.181.0 \
  semgrep scan --metrics=off --disable-version-check \
  --config /src/labs/lab08-taint-rule/rule.yaml /src/labs/lab08-taint-rule/practice.java


Должен помечаться только handleVulnerable.

## Проверка чекером (скрытый набор)

Загрузите образ чекера (один раз) и прогоните его:

docker load -i images/checkers.tar
docker run --rm -v "$PWD/labs/lab08-taint-rule/rule.yaml:/rule.yaml:ro" homeshop/lab08-checker:1


При верной классификации всего скрытого набора чекер напечатает токен.

## Вопросы (ответы вводятся на Stepik)

1. Вставьте токен, который напечатал чекер при успешной проверке.
2. Почему здесь нужен режим taint, а не простой шаблон $Q.exec(...)?