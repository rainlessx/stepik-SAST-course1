// Тренировочный файл для локальной отладки правила (не для сдачи).
// Правило должно пометить handleVulnerable (ввод доходит до exec) и не трогать
// handleSafe (в exec уходит константа).
public class Practice {
    LegacyQuery legacyQuery;

    void handleVulnerable(HttpServletRequest request) {
        String status = request.getParameter("status");
        legacyQuery.exec("SELECT count(*) FROM orders WHERE status = '" + status + "'");
    }

    void handleSafe(HttpServletRequest request) {
        String note = request.getParameter("note");
        System.out.println("report requested by filter: " + note);
        legacyQuery.exec("SELECT status, count(*) FROM orders GROUP BY status");
    }
}
