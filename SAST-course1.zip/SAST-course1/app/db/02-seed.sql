-- HomeShop seed data for local development and tests.

-- Products -------------------------------------------------------------------
INSERT INTO storefront.products (sku, name, description, category, price_cents, stock, image_name) VALUES
 ('KIT-001', 'Ceramic Dinner Plate Set',      'Set of 6 glazed ceramic dinner plates.',       'kitchen',  4990, 120, 'plate-set.png'),
 ('KIT-002', 'Stainless Steel Saucepan',       '2L saucepan with glass lid.',                  'kitchen',  3250,  80, 'saucepan.png'),
 ('KIT-003', 'Bamboo Cutting Board',           'Large bamboo cutting board.',                  'kitchen',  1890, 200, 'cutting-board.png'),
 ('KIT-004', 'Nonstick Frying Pan 28cm',       'Nonstick aluminium frying pan.',               'kitchen',  2790,  95, 'frying-pan.png'),
 ('KIT-005', 'Glass Storage Jar Set',          'Three airtight glass jars.',                   'kitchen',  2290, 140, 'jars.png'),
 ('KIT-006', 'Silicone Spatula Trio',          'Heat-resistant silicone spatulas.',            'kitchen',   990, 300, 'spatulas.png'),
 ('BTH-001', 'Cotton Bath Towel',              '550gsm cotton bath towel.',                    'bath',     1590, 260, 'towel.png'),
 ('BTH-002', 'Bamboo Bath Mat',                'Slatted bamboo bath mat.',                     'bath',     2490, 110, 'bath-mat.png'),
 ('BTH-003', 'Ceramic Soap Dispenser',         'Refillable ceramic soap dispenser.',           'bath',     1290, 175, 'soap-dispenser.png'),
 ('BTH-004', 'Shower Caddy Organizer',         'Rust-proof shower caddy.',                     'bath',     1990,  90, 'shower-caddy.png'),
 ('BED-001', 'Microfibre Duvet Cover',         'Double-size microfibre duvet cover.',          'bedroom',  3990,  70, 'duvet.png'),
 ('BED-002', 'Memory Foam Pillow',             'Contour memory foam pillow.',                  'bedroom',  2890, 130, 'pillow.png'),
 ('BED-003', 'Linen Fitted Sheet',             'Stonewashed linen fitted sheet.',              'bedroom',  4590,  55, 'sheet.png'),
 ('BED-004', 'Wool Throw Blanket',             'Soft wool blend throw.',                       'bedroom',  5490,  40, 'throw.png'),
 ('LGT-001', 'LED Desk Lamp',                  'Dimmable LED desk lamp.',                      'lighting', 3490,  85, 'desk-lamp.png'),
 ('LGT-002', 'Floor Reading Lamp',             'Adjustable floor reading lamp.',               'lighting', 6990,  30, 'floor-lamp.png'),
 ('LGT-003', 'String Fairy Lights 10m',        'Warm white indoor fairy lights.',              'lighting', 1490, 220, 'fairy-lights.png'),
 ('LGT-004', 'Bedside Touch Lamp',             'Touch-dimmable bedside lamp.',                 'lighting', 2690,  95, 'touch-lamp.png'),
 ('DEC-001', 'Framed Wall Art Print',          'A3 framed botanical print.',                   'decor',    2190, 150, 'wall-art.png'),
 ('DEC-002', 'Scented Soy Candle',             'Vanilla soy candle, 40h burn.',                'decor',    1190, 310, 'candle.png'),
 ('DEC-003', 'Ceramic Plant Pot',              'Matte ceramic pot, 15cm.',                     'decor',    1390, 240, 'plant-pot.png'),
 ('DEC-004', 'Woven Wall Hanging',             'Handwoven cotton wall hanging.',               'decor',    3290,  60, 'wall-hanging.png'),
 ('DEC-005', 'Decorative Mirror Round',        'Round framed decorative mirror.',              'decor',    4890,  45, 'mirror.png'),
 ('STO-001', 'Fabric Storage Basket',          'Collapsible fabric storage basket.',           'storage',  1690, 180, 'basket.png'),
 ('STO-002', 'Stackable Storage Box',          'Clear stackable storage box 20L.',             'storage',  1990, 160, 'storage-box.png'),
 ('STO-003', 'Over-Door Hook Rack',            'Five-hook over-door rack.',                     'storage',   890, 280, 'hook-rack.png'),
 ('STO-004', 'Shoe Storage Bench',             'Entryway shoe storage bench.',                 'storage',  7990,  25, 'shoe-bench.png'),
 ('STO-005', 'Drawer Divider Set',             'Adjustable drawer dividers.',                  'storage',  1290, 200, 'drawer-divider.png');

-- Customers (password for all seeded accounts: "password123") --------------
INSERT INTO storefront.customers (email, display_name, password_hash) VALUES
 ('anna.smirnova@example.com',  'Anna Smirnova',  '482c811da5d5b4bc6d497ffa98491e38'),
 ('igor.petrov@example.com',    'Igor Petrov',    '482c811da5d5b4bc6d497ffa98491e38'),
 ('maria.volkova@example.com',  'Maria Volkova',  '482c811da5d5b4bc6d497ffa98491e38'),
 ('pavel.orlov@example.com',    'Pavel Orlov',    '482c811da5d5b4bc6d497ffa98491e38'),
 ('elena.kuznetsova@example.com','Elena Kuznetsova','482c811da5d5b4bc6d497ffa98491e38');

-- Employees (admin / manager). Passwords hashed with bcrypt via pgcrypto.
-- admin password: "admin-local-pw" | manager password: "manager-local-pw"
INSERT INTO backoffice.employees (username, display_name, password_hash, role, team) VALUES
 ('admin',   'Site Administrator', crypt('admin-local-pw',   gen_salt('bf', 10)), 'ADMIN',   NULL),
 ('manager', 'Store Manager',      crypt('manager-local-pw', gen_salt('bf', 10)), 'MANAGER', 'south');

-- Back-office settings -------------------------------------------------------
INSERT INTO backoffice.settings (key, value) VALUES
 ('reports.retention_days', '30'),
 ('recommendations.size',   '6'),
 ('orders.export_scope',    'ownteam');

-- Orders ---------------------------------------------------------------------
INSERT INTO storefront.orders (id, customer_id, status, greeting_message, created_at) VALUES
 (1,  1, 'shipped',   'Happy housewarming!',        now() - interval '20 days'),
 (2,  1, 'new',       '',                           now() - interval '2 days'),
 (3,  2, 'shipped',   'Enjoy your new kitchen!',    now() - interval '18 days'),
 (4,  2, 'cancelled', '',                           now() - interval '15 days'),
 (5,  3, 'delivered', 'With love from all of us',   now() - interval '12 days'),
 (6,  3, 'new',       '',                           now() - interval '1 day'),
 (7,  4, 'shipped',   'Congratulations!',           now() - interval '9 days'),
 (8,  4, 'delivered', '',                           now() - interval '7 days'),
 (9,  5, 'new',       'Welcome home',               now() - interval '5 days'),
 (10, 5, 'shipped',   '',                           now() - interval '4 days'),
 (11, 1, 'delivered', 'Best wishes',                now() - interval '30 days'),
 (12, 3, 'new',       '',                           now() - interval '3 hours');
SELECT setval('storefront.orders_id_seq', 12, true);

INSERT INTO storefront.order_items (order_id, product_id, quantity, unit_price_cents) VALUES
 (1,  1, 1, 4990), (1,  6, 2,  990),
 (2,  2, 1, 3250), (2,  3, 1, 1890),
 (3,  7, 4, 1590),
 (4,  15,1, 3490),
 (5,  11,1, 3990), (5, 12, 2, 2890),
 (6,  20,3, 1190),
 (7,  16,1, 6990), (7, 19, 1, 2190),
 (8,  24,2, 1690), (8, 26, 1,  890),
 (9,  5, 1, 2290), (9,  4, 1, 2790),
 (10, 13,1, 4590),
 (11, 28,1, 1290), (11, 25, 2, 1990),
 (12, 9, 1, 2290), (12, 2, 1, 3250);

UPDATE storefront.orders o
SET total_cents = s.total
FROM (
    SELECT order_id, SUM(quantity * unit_price_cents) AS total
    FROM storefront.order_items GROUP BY order_id
) s
WHERE o.id = s.order_id;

-- Order assignments: each order is handled by a regional team -----------------
INSERT INTO backoffice.order_assignments (order_id, team) VALUES
 (1, 'north'), (2, 'south'), (3, 'north'),  (4, 'south'),
 (5, 'north'), (6, 'south'), (7, 'north'),  (8, 'south'),
 (9, 'north'), (10, 'south'), (11, 'north'), (12, 'south');
