-- HomeShop database schema.
-- Two independent schemas sharing one database.
-- The back office reads order/customer data from the storefront schema.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS storefront;
CREATE SCHEMA IF NOT EXISTS backoffice;

-- ---------------------------------------------------------------------------
-- storefront
-- ---------------------------------------------------------------------------

CREATE TABLE storefront.products (
    id          SERIAL PRIMARY KEY,
    sku         TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    category    TEXT NOT NULL,
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    stock       INTEGER NOT NULL DEFAULT 0,
    image_name  TEXT NOT NULL DEFAULT 'placeholder.png',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE storefront.customers (
    id            SERIAL PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE,
    display_name  TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE storefront.orders (
    id               SERIAL PRIMARY KEY,
    customer_id      INTEGER NOT NULL REFERENCES storefront.customers(id),
    status           TEXT NOT NULL DEFAULT 'new',
    total_cents      INTEGER NOT NULL DEFAULT 0,
    greeting_message TEXT NOT NULL DEFAULT '',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE storefront.order_items (
    id               SERIAL PRIMARY KEY,
    order_id         INTEGER NOT NULL REFERENCES storefront.orders(id),
    product_id       INTEGER NOT NULL REFERENCES storefront.products(id),
    quantity         INTEGER NOT NULL CHECK (quantity > 0),
    unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0)
);

CREATE INDEX idx_products_category ON storefront.products(category);
CREATE INDEX idx_orders_customer ON storefront.orders(customer_id);
CREATE INDEX idx_order_items_order ON storefront.order_items(order_id);

-- ---------------------------------------------------------------------------
-- backoffice
-- ---------------------------------------------------------------------------

CREATE TABLE backoffice.employees (
    id            SERIAL PRIMARY KEY,
    username      TEXT NOT NULL UNIQUE,
    display_name  TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('ADMIN', 'MANAGER')),
    team          TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE backoffice.password_reset_tokens (
    id          SERIAL PRIMARY KEY,
    employee_id INTEGER NOT NULL REFERENCES backoffice.employees(id),
    token       TEXT NOT NULL UNIQUE,
    expires_at  TIMESTAMPTZ NOT NULL,
    used        BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE backoffice.settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE backoffice.supplier_pricelists (
    id          SERIAL PRIMARY KEY,
    supplier    TEXT NOT NULL,
    sku         TEXT NOT NULL,
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    imported_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE backoffice.order_assignments (
    order_id INTEGER PRIMARY KEY REFERENCES storefront.orders(id),
    team     TEXT NOT NULL
);

CREATE INDEX idx_reset_tokens_token ON backoffice.password_reset_tokens(token);
CREATE INDEX idx_order_assignments_team ON backoffice.order_assignments(team);
