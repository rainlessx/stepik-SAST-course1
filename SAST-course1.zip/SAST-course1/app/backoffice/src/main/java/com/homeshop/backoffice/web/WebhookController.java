package com.homeshop.backoffice.web;

import com.homeshop.backoffice.service.WebhookService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/webhooks")
public class WebhookController {

    private final WebhookService webhooks;

    public WebhookController(WebhookService webhooks) {
        this.webhooks = webhooks;
    }

    @PostMapping("/verify")
    public WebhookService.WebhookResult verify(@RequestBody Map<String, String> body) throws IOException {
        String url = body.getOrDefault("url", "");
        return webhooks.verify(url);
    }
}
