package com.homeshop.backoffice.service;

import com.homeshop.backoffice.legacy.LegacyQuery;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {

    private final Path baseDir;
    private final LegacyQuery legacyQuery;

    public ReportService(@Value("${homeshop.reports-dir}") String reportsDir,
                         LegacyQuery legacyQuery) throws IOException {
        this.baseDir = Paths.get(reportsDir);
        this.legacyQuery = legacyQuery;
        Files.createDirectories(this.baseDir);
    }

    public byte[] readReport(String name) throws IOException {
        File target = new File(baseDir.toFile(), name);
        if (!target.exists()) {
            throw new NoSuchFileException(name);
        }
        return Files.readAllBytes(target.toPath());
    }

    public List<Map<String, Object>> salesSummary() {
        return legacyQuery.exec(
                "SELECT status, COUNT(*) AS order_count FROM storefront.orders GROUP BY status");
    }

    public List<Map<String, Object>> salesByStatus(String status) {
        return legacyQuery.exec(
                "SELECT status, COUNT(*) AS order_count FROM storefront.orders "
                + "WHERE status = '" + status + "' GROUP BY status");
    }

    public List<Map<String, Object>> ordersByCustomer(String customer) {
        return legacyQuery.exec(
                "SELECT o.id, o.status, o.total_cents FROM storefront.orders o "
                + "JOIN storefront.customers c ON c.id = o.customer_id "
                + "WHERE c.display_name ILIKE '%" + customer + "%' ORDER BY o.id");
    }
}
