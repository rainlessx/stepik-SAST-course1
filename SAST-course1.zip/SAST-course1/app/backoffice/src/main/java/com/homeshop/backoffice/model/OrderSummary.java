package com.homeshop.backoffice.model;

import java.time.Instant;

public record OrderSummary(
        long id,
        String customerName,
        String status,
        long totalCents,
        Instant createdAt) {
}
