package com.homeshop.backoffice.web;

import com.homeshop.backoffice.service.ReportService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ReportService reports;

    public ReportController(ReportService reports) {
        this.reports = reports;
    }

    @GetMapping
    public ResponseEntity<byte[]> export(@RequestParam String name) throws IOException {
        byte[] data = reports.readReport(name);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + name + "\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(data);
    }

    @GetMapping("/summary")
    public List<Map<String, Object>> summary() {
        return reports.salesSummary();
    }

    @GetMapping("/by-status")
    public List<Map<String, Object>> byStatus(@RequestParam String status) {
        return reports.salesByStatus(status);
    }

    @GetMapping("/by-customer")
    public List<Map<String, Object>> byCustomer(@RequestParam String customer) {
        return reports.ordersByCustomer(customer);
    }
}
