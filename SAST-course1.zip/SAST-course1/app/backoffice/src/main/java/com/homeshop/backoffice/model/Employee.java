package com.homeshop.backoffice.model;

public record Employee(long id, String username, String passwordHash, String role, String team) {
}
