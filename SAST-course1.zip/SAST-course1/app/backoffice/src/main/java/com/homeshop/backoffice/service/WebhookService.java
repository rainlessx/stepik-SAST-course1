package com.homeshop.backoffice.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

@Service
public class WebhookService {

    public record WebhookResult(String url, int statusCode) {
    }

    public WebhookResult verify(String rawUrl) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(rawUrl).openConnection();
        connection.setConnectTimeout(3000);
        connection.setReadTimeout(3000);
        connection.setRequestMethod("HEAD");
        try {
            return new WebhookResult(rawUrl, connection.getResponseCode());
        } finally {
            connection.disconnect();
        }
    }
}
