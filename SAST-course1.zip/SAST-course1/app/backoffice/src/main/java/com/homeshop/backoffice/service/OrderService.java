package com.homeshop.backoffice.service;

import com.homeshop.backoffice.model.OrderDetail;
import com.homeshop.backoffice.model.OrderSummary;
import com.homeshop.backoffice.repo.EmployeeRepository;
import com.homeshop.backoffice.repo.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    private final OrderRepository orders;
    private final EmployeeRepository employees;

    public OrderService(OrderRepository orders, EmployeeRepository employees) {
        this.orders = orders;
        this.employees = employees;
    }

    public List<OrderSummary> list(String username) {
        String team = teamOf(username);
        return team == null ? orders.findAll() : orders.findByTeam(team);
    }

    public List<OrderSummary> searchByCustomer(String username, String customer) {
        return orders.searchByCustomer(customer, teamOf(username));
    }

    public Optional<OrderDetail> getOrder(long id) {
        return orders.findById(id)
                .map(summary -> new OrderDetail(summary, orders.findItems(id)));
    }

    private String teamOf(String username) {
        return employees.findByUsername(username).map(e -> e.team()).orElse(null);
    }
}
