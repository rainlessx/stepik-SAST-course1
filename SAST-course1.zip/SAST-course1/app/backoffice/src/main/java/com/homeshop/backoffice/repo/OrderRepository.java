package com.homeshop.backoffice.repo;

import com.homeshop.backoffice.model.OrderItem;
import com.homeshop.backoffice.model.OrderSummary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class OrderRepository {

    private static final String BASE_QUERY =
            "SELECT o.id, c.display_name AS customer_name, o.status, o.total_cents, o.created_at "
            + "FROM storefront.orders o "
            + "JOIN storefront.customers c ON c.id = o.customer_id";

    private final JdbcTemplate jdbc;

    private final RowMapper<OrderSummary> summaryMapper = (rs, n) -> new OrderSummary(
            rs.getLong("id"),
            rs.getString("customer_name"),
            rs.getString("status"),
            rs.getLong("total_cents"),
            rs.getTimestamp("created_at").toInstant());

    public OrderRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<OrderSummary> findAll() {
        return jdbc.query(BASE_QUERY + " ORDER BY o.created_at DESC", summaryMapper);
    }

    public List<OrderSummary> findByTeam(String team) {
        return jdbc.query(
                BASE_QUERY
                + " JOIN backoffice.order_assignments a ON a.order_id = o.id "
                + "WHERE a.team = ? ORDER BY o.created_at DESC",
                summaryMapper,
                team);
    }

    public Optional<OrderSummary> findById(long id) {
        return jdbc.query(BASE_QUERY + " WHERE o.id = " + id, summaryMapper)
                .stream().findFirst();
    }

    public List<OrderSummary> searchByCustomer(String term, String team) {
        String sql = BASE_QUERY
                + " WHERE c.display_name ILIKE '%" + term + "%'";
        if (team == null) {
            return jdbc.query(sql + " ORDER BY o.created_at DESC", summaryMapper);
        }
        return jdbc.query(
                sql + " AND o.id IN (SELECT order_id FROM backoffice.order_assignments WHERE team = ?) "
                + "ORDER BY o.created_at DESC",
                summaryMapper,
                team);
    }

    public List<OrderItem> findItems(long orderId) {
        return jdbc.query(
                "SELECT p.name, oi.quantity, oi.unit_price_cents "
                + "FROM storefront.order_items oi "
                + "JOIN storefront.products p ON p.id = oi.product_id "
                + "WHERE oi.order_id = ?",
                (rs, n) -> new OrderItem(
                        rs.getString("name"),
                        rs.getInt("quantity"),
                        rs.getLong("unit_price_cents")),
                orderId);
    }
}
