package com.homeshop.backoffice.repo;

import com.homeshop.backoffice.model.Employee;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class EmployeeRepository {

    private final JdbcTemplate jdbc;

    public EmployeeRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Optional<Employee> findByUsername(String username) {
        List<Employee> rows = jdbc.query(
                "SELECT id, username, password_hash, role, team FROM backoffice.employees WHERE username = ?",
                (rs, n) -> new Employee(
                        rs.getLong("id"),
                        rs.getString("username"),
                        rs.getString("password_hash"),
                        rs.getString("role"),
                        rs.getString("team")),
                username);
        return rows.stream().findFirst();
    }

    public void updatePassword(long employeeId, String passwordHash) {
        jdbc.update("UPDATE backoffice.employees SET password_hash = ? WHERE id = ?",
                passwordHash, employeeId);
    }
}
