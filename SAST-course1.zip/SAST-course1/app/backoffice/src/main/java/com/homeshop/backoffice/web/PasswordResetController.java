package com.homeshop.backoffice.web;

import com.homeshop.backoffice.service.PasswordResetService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/password-reset")
public class PasswordResetController {

    private final PasswordResetService passwordReset;

    public PasswordResetController(PasswordResetService passwordReset) {
        this.passwordReset = passwordReset;
    }

    @PostMapping("/request")
    public Map<String, String> request(@RequestBody Map<String, String> body) {
        passwordReset.createToken(body.getOrDefault("username", ""));
        return Map.of("status", "requested");
    }

    @PostMapping("/confirm")
    public Map<String, String> confirm(@RequestBody Map<String, String> body) {
        passwordReset.resetPassword(
                body.getOrDefault("token", ""),
                body.getOrDefault("newPassword", ""));
        return Map.of("status", "ok");
    }
}
