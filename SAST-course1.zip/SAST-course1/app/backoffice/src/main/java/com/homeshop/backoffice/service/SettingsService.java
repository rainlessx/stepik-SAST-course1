package com.homeshop.backoffice.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class SettingsService {

    private final JdbcTemplate jdbc;

    public SettingsService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public byte[] export() throws IOException {
        List<Map.Entry<String, String>> rows = jdbc.query(
                "SELECT key, value FROM backoffice.settings ORDER BY key",
                (rs, n) -> Map.entry(rs.getString("key"), rs.getString("value")));
        LinkedHashMap<String, String> values = new LinkedHashMap<>();
        for (Map.Entry<String, String> row : rows) {
            values.put(row.getKey(), row.getValue());
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(out)) {
            oos.writeObject(values);
        }
        return out.toByteArray();
    }

    public int importSettings(byte[] data) throws IOException {
        Map<String, String> values;
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data))) {
            @SuppressWarnings("unchecked")
            Map<String, String> parsed = (Map<String, String>) ois.readObject();
            values = parsed;
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("invalid settings file");
        }
        int count = 0;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            jdbc.update(
                    "INSERT INTO backoffice.settings (key, value) VALUES (?, ?) "
                    + "ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
                    entry.getKey(), entry.getValue());
            count++;
        }
        return count;
    }
}
