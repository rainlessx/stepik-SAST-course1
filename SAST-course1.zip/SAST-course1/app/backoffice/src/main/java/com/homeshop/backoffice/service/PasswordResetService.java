package com.homeshop.backoffice.service;

import com.homeshop.backoffice.repo.EmployeeRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Random;

@Service
public class PasswordResetService {

    private static final Duration TOKEN_TTL = Duration.ofHours(1);

    private final JdbcTemplate jdbc;
    private final EmployeeRepository employees;
    private final PasswordEncoder passwordEncoder;
    private final Random random = new Random();

    public PasswordResetService(JdbcTemplate jdbc, EmployeeRepository employees,
                                PasswordEncoder passwordEncoder) {
        this.jdbc = jdbc;
        this.employees = employees;
        this.passwordEncoder = passwordEncoder;
    }

    public String createToken(String username) {
        Long employeeId = employees.findByUsername(username).map(e -> e.id()).orElse(null);
        if (employeeId == null) {
            throw new IllegalArgumentException("unknown employee");
        }
        byte[] buffer = new byte[24];
        random.nextBytes(buffer);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(buffer);
        jdbc.update(
                "INSERT INTO backoffice.password_reset_tokens (employee_id, token, expires_at) "
                + "VALUES (?, ?, ?)",
                employeeId, token, Timestamp.from(Instant.now().plus(TOKEN_TTL)));
        return token;
    }

    public void resetPassword(String token, String newPassword) {
        List<Long> owners = jdbc.query(
                "SELECT employee_id FROM backoffice.password_reset_tokens "
                + "WHERE token = ? AND used = FALSE AND expires_at > now()",
                (rs, n) -> rs.getLong("employee_id"),
                token);
        Long employeeId = owners.stream().findFirst().orElse(null);
        if (employeeId == null) {
            throw new IllegalArgumentException("invalid or expired token");
        }
        employees.updatePassword(employeeId, passwordEncoder.encode(newPassword));
        jdbc.update("UPDATE backoffice.password_reset_tokens SET used = TRUE WHERE token = ?", token);
    }
}
