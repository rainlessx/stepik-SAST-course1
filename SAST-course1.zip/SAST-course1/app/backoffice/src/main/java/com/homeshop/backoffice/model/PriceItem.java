package com.homeshop.backoffice.model;

public record PriceItem(String sku, long priceCents) {
}
