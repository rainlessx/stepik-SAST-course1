package com.homeshop.backoffice.service;

import com.homeshop.backoffice.model.PriceItem;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class PriceListService {

    private final JdbcTemplate jdbc;

    public PriceListService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<PriceItem> importPriceList(String supplier, byte[] xml) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new ByteArrayInputStream(xml));

        NodeList nodes = document.getElementsByTagName("item");
        List<PriceItem> items = new ArrayList<>();
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            String sku = textOf(element, "sku");
            long price = Long.parseLong(textOf(element, "price"));
            items.add(new PriceItem(sku, price));
            jdbc.update(
                    "INSERT INTO backoffice.supplier_pricelists (supplier, sku, price_cents) "
                    + "VALUES (?, ?, ?)",
                    supplier, sku, price);
        }
        return items;
    }

    private static String textOf(Element element, String tag) {
        NodeList list = element.getElementsByTagName(tag);
        if (list.getLength() == 0) {
            throw new IllegalArgumentException("missing element: " + tag);
        }
        return list.item(0).getTextContent().trim();
    }
}
