package com.homeshop.backoffice.model;

public record Recommendation(long id, String name, long priceCents) {
}
