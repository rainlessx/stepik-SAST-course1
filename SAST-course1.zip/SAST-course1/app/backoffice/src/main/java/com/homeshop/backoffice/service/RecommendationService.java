package com.homeshop.backoffice.service;

import com.homeshop.backoffice.model.Recommendation;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

@Service
public class RecommendationService {

    private final JdbcTemplate jdbc;

    public RecommendationService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Recommendation> recommend(int size) {
        List<Recommendation> products = new ArrayList<>(jdbc.query(
                "SELECT id, name, price_cents FROM storefront.products",
                (rs, n) -> new Recommendation(
                        rs.getLong("id"),
                        rs.getString("name"),
                        rs.getLong("price_cents"))));
        Collections.shuffle(products, new Random());
        return products.stream().limit(Math.max(0, size)).toList();
    }
}
