package com.homeshop.backoffice.legacy;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Thin wrapper around the legacy reporting data source. Callers pass a fully
 * built SQL statement and receive the rows as generic maps.
 */
@Component
public class LegacyQuery {

    private final JdbcTemplate jdbc;

    public LegacyQuery(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Map<String, Object>> exec(String sql) {
        return jdbc.queryForList(sql);
    }
}
