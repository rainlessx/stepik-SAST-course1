package com.homeshop.backoffice.web;

import com.homeshop.backoffice.model.OrderDetail;
import com.homeshop.backoffice.model.OrderSummary;
import com.homeshop.backoffice.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orders;

    public OrderController(OrderService orders) {
        this.orders = orders;
    }

    @GetMapping
    public List<OrderSummary> list(Authentication authentication) {
        return orders.list(authentication.getName());
    }

    @GetMapping("/search")
    public List<OrderSummary> search(@RequestParam String customer, Authentication authentication) {
        return orders.searchByCustomer(authentication.getName(), customer);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderDetail> get(@PathVariable long id) {
        return orders.getOrder(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
