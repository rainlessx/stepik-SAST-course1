package com.homeshop.backoffice.model;

import java.util.List;

public record OrderDetail(OrderSummary summary, List<OrderItem> items) {
}
