package com.homeshop.backoffice.model;

public record OrderItem(String productName, int quantity, long unitPriceCents) {
}
