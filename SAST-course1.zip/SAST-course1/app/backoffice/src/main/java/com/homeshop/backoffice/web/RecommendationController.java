package com.homeshop.backoffice.web;

import com.homeshop.backoffice.model.Recommendation;
import com.homeshop.backoffice.service.RecommendationService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {

    private final RecommendationService recommendations;

    public RecommendationController(RecommendationService recommendations) {
        this.recommendations = recommendations;
    }

    @GetMapping
    public List<Recommendation> list(@RequestParam(defaultValue = "6") int size) {
        return recommendations.recommend(size);
    }
}
