package com.homeshop.backoffice.web;

import com.homeshop.backoffice.model.PriceItem;
import com.homeshop.backoffice.service.PriceListService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pricelists")
public class PriceListController {

    private final PriceListService priceLists;

    public PriceListController(PriceListService priceLists) {
        this.priceLists = priceLists;
    }

    @PostMapping("/import")
    public Map<String, Object> importPriceList(@RequestParam String supplier,
                                               @RequestParam("file") MultipartFile file) throws Exception {
        List<PriceItem> items = priceLists.importPriceList(supplier, file.getBytes());
        return Map.of("supplier", supplier, "imported", items.size(), "items", items);
    }
}
