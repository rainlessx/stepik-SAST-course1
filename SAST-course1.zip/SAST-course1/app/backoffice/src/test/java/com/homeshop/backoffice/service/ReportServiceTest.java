package com.homeshop.backoffice.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ReportServiceTest {

    @TempDir
    Path reportsDir;

    @Test
    void readsReportWithinBaseDir() throws Exception {
        Files.writeString(reportsDir.resolve("sales.txt"), "report-body");
        ReportService service = new ReportService(reportsDir.toString(), null);
        assertEquals("report-body",
                new String(service.readReport("sales.txt"), StandardCharsets.UTF_8));
    }

    @Test
    void reportsMissingFile() throws Exception {
        ReportService service = new ReportService(reportsDir.toString(), null);
        assertThrows(NoSuchFileException.class, () -> service.readReport("missing.txt"));
    }
}
