package com.homeshop.backoffice.web;

import com.homeshop.backoffice.config.SecurityConfig;
import com.homeshop.backoffice.model.OrderDetail;
import com.homeshop.backoffice.model.OrderSummary;
import com.homeshop.backoffice.service.OrderService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(OrderController.class)
@Import(SecurityConfig.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockitoBean
    private OrderService orderService;

    @MockitoBean
    private UserDetailsService userDetailsService;

    @Test
    @WithMockUser(roles = "ADMIN")
    void listReturnsOrders() throws Exception {
        when(orderService.list("user")).thenReturn(List.of(
                new OrderSummary(1, "Anna Smirnova", "new", 1000, Instant.now())));
        mvc.perform(get("/api/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].customerName").value("Anna Smirnova"));
    }

    @Test
    @WithMockUser(roles = "MANAGER")
    void searchIsAllowedForManager() throws Exception {
        when(orderService.searchByCustomer("user", "Anna")).thenReturn(List.of());
        mvc.perform(get("/api/orders/search").param("customer", "Anna"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getByIdReturnsDetail() throws Exception {
        when(orderService.getOrder(5L)).thenReturn(Optional.of(
                new OrderDetail(new OrderSummary(5, "Igor Petrov", "new", 500, Instant.now()), List.of())));
        mvc.perform(get("/api/orders/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.summary.id").value(5));
    }

    @Test
    @WithMockUser(roles = "MANAGER")
    void getByIdReturnsOrderForManager() throws Exception {
        when(orderService.getOrder(5L)).thenReturn(Optional.of(
                new OrderDetail(new OrderSummary(5, "Igor Petrov", "new", 500, Instant.now()), List.of())));
        mvc.perform(get("/api/orders/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.summary.id").value(5));
    }

    @Test
    void listRequiresAuthentication() throws Exception {
        mvc.perform(get("/api/orders"))
                .andExpect(status().isUnauthorized());
    }
}
