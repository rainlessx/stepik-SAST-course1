package com.homeshop.backoffice.service;

import com.homeshop.backoffice.model.Employee;
import com.homeshop.backoffice.repo.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class PasswordResetServiceTest {

    @Test
    void createTokenReturnsNonTrivialToken() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        EmployeeRepository employees = mock(EmployeeRepository.class);
        PasswordEncoder encoder = mock(PasswordEncoder.class);
        when(employees.findByUsername("admin"))
                .thenReturn(Optional.of(new Employee(1, "admin", "hash", "ADMIN", null)));

        PasswordResetService service = new PasswordResetService(jdbc, employees, encoder);
        String token = service.createToken("admin");

        assertNotNull(token);
        assertTrue(token.length() >= 20);
        verify(jdbc).update(anyString(), eq(1L), eq(token), any());
    }

    @Test
    void createTokenFailsForUnknownUser() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        EmployeeRepository employees = mock(EmployeeRepository.class);
        PasswordEncoder encoder = mock(PasswordEncoder.class);
        when(employees.findByUsername("ghost")).thenReturn(Optional.empty());

        PasswordResetService service = new PasswordResetService(jdbc, employees, encoder);
        assertThrows(IllegalArgumentException.class, () -> service.createToken("ghost"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void resetPasswordWithValidTokenUpdatesHash() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        EmployeeRepository employees = mock(EmployeeRepository.class);
        PasswordEncoder encoder = mock(PasswordEncoder.class);
        when(jdbc.query(anyString(), any(RowMapper.class), eq("token-1"))).thenReturn(List.of(1L));
        when(encoder.encode("new-pw")).thenReturn("encoded-pw");

        PasswordResetService service = new PasswordResetService(jdbc, employees, encoder);
        service.resetPassword("token-1", "new-pw");

        verify(employees).updatePassword(1L, "encoded-pw");
    }

    @Test
    @SuppressWarnings("unchecked")
    void resetPasswordFailsForInvalidToken() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        EmployeeRepository employees = mock(EmployeeRepository.class);
        PasswordEncoder encoder = mock(PasswordEncoder.class);
        when(jdbc.query(anyString(), any(RowMapper.class), eq("bad"))).thenReturn(List.of());

        PasswordResetService service = new PasswordResetService(jdbc, employees, encoder);
        assertThrows(IllegalArgumentException.class, () -> service.resetPassword("bad", "x"));
    }
}
