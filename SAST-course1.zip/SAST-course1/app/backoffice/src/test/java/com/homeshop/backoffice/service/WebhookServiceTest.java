package com.homeshop.backoffice.service;

import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.InetSocketAddress;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class WebhookServiceTest {

    private final WebhookService service = new WebhookService();

    @Test
    void returnsStatusForReachableUrl() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/hook", exchange -> {
            exchange.sendResponseHeaders(200, -1);
            exchange.close();
        });
        server.start();
        try {
            int port = server.getAddress().getPort();
            WebhookService.WebhookResult result = service.verify("http://127.0.0.1:" + port + "/hook");
            assertEquals(200, result.statusCode());
        } finally {
            server.stop(0);
        }
    }

    @Test
    void rejectsMalformedUrl() {
        assertThrows(IOException.class, () -> service.verify("not-a-url"));
    }
}
