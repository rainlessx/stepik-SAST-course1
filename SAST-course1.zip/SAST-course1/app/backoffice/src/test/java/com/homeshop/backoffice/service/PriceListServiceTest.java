package com.homeshop.backoffice.service;

import com.homeshop.backoffice.model.PriceItem;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class PriceListServiceTest {

    @Test
    void parsesItemsAndStoresThem() throws Exception {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        PriceListService service = new PriceListService(jdbc);

        String xml = "<pricelist>"
                + "<item><sku>KIT-001</sku><price>4990</price></item>"
                + "<item><sku>KIT-002</sku><price>3250</price></item>"
                + "</pricelist>";

        List<PriceItem> items = service.importPriceList("ACME", xml.getBytes(StandardCharsets.UTF_8));

        assertEquals(2, items.size());
        assertEquals("KIT-001", items.get(0).sku());
        assertEquals(4990, items.get(0).priceCents());
        verify(jdbc, times(2)).update(anyString(), any(), any(), any());
    }
}
