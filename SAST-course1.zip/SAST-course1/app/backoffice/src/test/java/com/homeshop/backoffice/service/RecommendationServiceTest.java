package com.homeshop.backoffice.service;

import com.homeshop.backoffice.model.Recommendation;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class RecommendationServiceTest {

    @Test
    @SuppressWarnings("unchecked")
    void returnsRequestedNumberOfItems() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        when(jdbc.query(anyString(), any(RowMapper.class))).thenReturn(List.of(
                new Recommendation(1, "A", 100),
                new Recommendation(2, "B", 200),
                new Recommendation(3, "C", 300),
                new Recommendation(4, "D", 400)));

        RecommendationService service = new RecommendationService(jdbc);
        assertEquals(3, service.recommend(3).size());
    }

    @Test
    @SuppressWarnings("unchecked")
    void sizeZeroReturnsEmptyList() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        when(jdbc.query(anyString(), any(RowMapper.class)))
                .thenReturn(List.of(new Recommendation(1, "A", 100)));

        RecommendationService service = new RecommendationService(jdbc);
        assertEquals(0, service.recommend(0).size());
    }
}
