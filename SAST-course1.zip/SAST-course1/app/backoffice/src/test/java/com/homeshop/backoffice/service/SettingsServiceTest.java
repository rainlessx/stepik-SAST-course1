package com.homeshop.backoffice.service;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SettingsServiceTest {

    @Test
    @SuppressWarnings("unchecked")
    void exportSerializesSettings() throws Exception {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        when(jdbc.query(anyString(), any(RowMapper.class)))
                .thenReturn(List.of(Map.entry("alpha", "1"), Map.entry("beta", "2")));

        SettingsService service = new SettingsService(jdbc);
        Object parsed = new ObjectInputStream(
                new ByteArrayInputStream(service.export())).readObject();

        assertTrue(parsed instanceof Map);
        Map<?, ?> values = (Map<?, ?>) parsed;
        assertEquals("1", values.get("alpha"));
        assertEquals("2", values.get("beta"));
    }

    @Test
    void importStoresEntries() throws Exception {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        SettingsService service = new SettingsService(jdbc);

        LinkedHashMap<String, String> values = new LinkedHashMap<>();
        values.put("x", "10");
        values.put("y", "20");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(out)) {
            oos.writeObject(values);
        }

        int count = service.importSettings(out.toByteArray());

        assertEquals(2, count);
        verify(jdbc, times(2)).update(anyString(), anyString(), anyString());
    }
}
