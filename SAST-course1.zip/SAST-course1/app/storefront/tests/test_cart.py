def test_add_to_cart_and_view(client):
    response = client.post(
        "/cart/add", data={"product_id": "1", "quantity": "2"}, follow_redirects=True
    )
    assert response.status_code == 200
    assert b"Ceramic Dinner Plate Set" in response.data
    # 4990 cents * 2 = 99.80
    assert b"99.80" in response.data


def test_cart_quantity_accumulates(client):
    client.post("/cart/add", data={"product_id": "6", "quantity": "1"})
    response = client.post(
        "/cart/add", data={"product_id": "6", "quantity": "2"}, follow_redirects=True
    )
    # 990 cents * 3 = 29.70
    assert b"29.70" in response.data


def test_remove_from_cart(client):
    client.post("/cart/add", data={"product_id": "2", "quantity": "1"})
    client.post("/cart/remove", data={"product_id": "2"}, follow_redirects=True)
    response = client.get("/cart")
    assert b"Your cart is empty" in response.data


def test_empty_cart(client):
    response = client.get("/cart")
    assert response.status_code == 200
    assert b"Your cart is empty" in response.data
