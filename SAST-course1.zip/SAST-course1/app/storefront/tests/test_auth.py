from tests.conftest import register_user


def test_register_logs_in_and_shows_profile(client):
    register_user(client)
    response = client.get("/profile")
    assert response.status_code == 200
    assert b"Buyer" in response.data


def test_profile_requires_login(client):
    response = client.get("/profile")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


def test_login_logout_cycle(client):
    email, password = register_user(client)
    client.post("/logout")
    assert client.get("/profile").status_code == 302

    response = client.post(
        "/login", data={"email": email, "password": password}, follow_redirects=True
    )
    assert response.status_code == 200
    assert client.get("/profile").status_code == 200


def test_login_invalid_credentials(client):
    response = client.post(
        "/login", data={"email": "nobody@example.com", "password": "wrong"}
    )
    assert response.status_code == 401


def test_login_local_next_redirect(client):
    email, password = register_user(client)
    client.post("/logout")
    response = client.post(
        "/login", data={"email": email, "password": password, "next": "/cart"}
    )
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/cart")
