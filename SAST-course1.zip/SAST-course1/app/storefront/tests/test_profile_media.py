import io

from tests.conftest import register_user, make_png_bytes


def test_avatar_accepts_png(client):
    register_user(client)
    data = {"avatar": (io.BytesIO(make_png_bytes()), "me.png")}
    response = client.post(
        "/profile/avatar",
        data=data,
        content_type="multipart/form-data",
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Avatar updated" in response.data


def test_avatar_rejects_wrong_extension(client):
    register_user(client)
    data = {"avatar": (io.BytesIO(b"just text"), "notes.txt")}
    response = client.post(
        "/profile/avatar",
        data=data,
        content_type="multipart/form-data",
        follow_redirects=True,
    )
    assert b"Unsupported file type" in response.data


def test_product_image_has_etag_and_304(client):
    response = client.get("/media/product/placeholder.png")
    assert response.status_code == 200
    etag = response.headers.get("ETag")
    assert etag

    cached = client.get(
        "/media/product/placeholder.png", headers={"If-None-Match": etag}
    )
    assert cached.status_code == 304


def test_internal_report_requires_login(client):
    assert client.get("/internal/reports/top-selling").status_code == 302


def test_internal_report_renders_for_user(client):
    register_user(client)
    response = client.get("/internal/reports/top-selling")
    assert response.status_code == 200
