def test_health(client):
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.get_json()["status"] == "ok"


def test_catalog_lists_products(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Ceramic Dinner Plate Set" in response.data


def test_catalog_sort_by_price(client):
    response = client.get("/?sort=price&dir=asc")
    assert response.status_code == 200


def test_catalog_filter_by_category(client):
    response = client.get("/?category=lighting")
    assert response.status_code == 200
    assert b"LED Desk Lamp" in response.data


def test_product_detail(client):
    response = client.get("/product/1")
    assert response.status_code == 200
    assert b"SKU:" in response.data


def test_product_detail_missing(client):
    assert client.get("/product/999999").status_code == 404


def test_search_finds_product(client):
    response = client.get("/search?q=lamp")
    assert response.status_code == 200
    assert b"Lamp" in response.data


def test_search_no_results(client):
    response = client.get("/search?q=zzzznotathing")
    assert response.status_code == 200
    assert b"No products found" in response.data
