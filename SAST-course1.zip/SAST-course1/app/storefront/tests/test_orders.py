from tests.conftest import register_user


def _checkout_two_items(client):
    register_user(client)
    client.post("/cart/add", data={"product_id": "1", "quantity": "2"})  # 4990 * 2
    client.post("/cart/add", data={"product_id": "6", "quantity": "1"})  # 990
    return client.post("/checkout", follow_redirects=True)


def test_checkout_uses_catalog_prices(client):
    response = _checkout_two_items(client)
    assert response.status_code == 200
    # 2 * 4990 + 990 = 10970 -> 109.70
    assert b"109.70" in response.data


def test_checkout_empty_cart_redirects_to_cart(client):
    register_user(client)
    response = client.post("/checkout", follow_redirects=True)
    assert response.status_code == 200
    assert b"Your cart is empty" in response.data


def test_invoice_download(client):
    response = _checkout_two_items(client)
    order_id = response.request.path.split("/")[2]
    invoice = client.get(f"/orders/invoice?file=invoice-{order_id}.txt")
    assert invoice.status_code == 200
    assert b"HomeShop invoice" in invoice.data


def test_greeting_card_renders_message(client):
    response = client.get("/orders/1/card?message=Happy%20Birthday")
    assert response.status_code == 200
    assert b"Happy Birthday" in response.data
