import struct
import tempfile
import uuid
import zlib

import pytest

from storefront import create_app
from storefront.config import Config


@pytest.fixture(scope="session")
def app():
    workdir = tempfile.mkdtemp(prefix="homeshop-test-")

    class TestConfig(Config):
        TESTING = True
        SECRET_KEY = "test-secret"
        AVATAR_DIR = f"{workdir}/avatars"
        INVOICE_DIR = f"{workdir}/invoices"
        TEMP_DIR = f"{workdir}/tmp"

    return create_app(TestConfig)


@pytest.fixture
def client(app):
    return app.test_client()


def make_png_bytes():
    """A minimal valid 1x1 truecolor PNG."""

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    ihdr = struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)
    idat = zlib.compress(b"\x00" + bytes((200, 200, 200)), 9)
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", ihdr)
        + chunk(b"IDAT", idat)
        + chunk(b"IEND", b"")
    )


def register_user(client, password="pw-123456"):
    email = f"user-{uuid.uuid4().hex[:10]}@example.com"
    client.post(
        "/register",
        data={"email": email, "display_name": "Buyer", "password": password},
    )
    return email, password
