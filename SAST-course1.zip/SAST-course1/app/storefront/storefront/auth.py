import hashlib
from functools import wraps

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
)

from .db import query, execute

bp = Blueprint("auth", __name__)


def _hash_password(password):
    return hashlib.md5(password.encode("utf-8")).hexdigest()


def current_user():
    user_id = session.get("user_id")
    if user_id is None:
        return None
    return query(
        "SELECT id, email, display_name FROM storefront.customers WHERE id = %s",
        (user_id,),
        one=True,
    )


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)

    return wrapped


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        display_name = request.form.get("display_name", "").strip() or email.split("@")[0]
        password = request.form["password"]
        if query(
            "SELECT id FROM storefront.customers WHERE email = %s", (email,), one=True
        ):
            flash("Email already registered")
            return render_template("register.html"), 400
        execute(
            "INSERT INTO storefront.customers (email, display_name, password_hash) "
            "VALUES (%s, %s, %s)",
            (email, display_name, _hash_password(password)),
        )
        row = query(
            "SELECT id FROM storefront.customers WHERE email = %s", (email,), one=True
        )
        session["user_id"] = row["id"]
        return redirect(url_for("catalog.index"))
    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    next_url = request.args.get("next", "")
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        user = query(
            "SELECT id, password_hash FROM storefront.customers WHERE email = %s",
            (email,),
            one=True,
        )
        if user and user["password_hash"] == _hash_password(password):
            session["user_id"] = user["id"]
            target = request.form.get("next") or next_url
            if target:
                return redirect(target)
            return redirect(url_for("catalog.index"))
        flash("Invalid credentials")
        return render_template("login.html", next=next_url), 401
    return render_template("login.html", next=next_url)


@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("catalog.index"))
