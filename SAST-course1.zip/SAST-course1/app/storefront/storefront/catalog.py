import random

from flask import Blueprint, render_template, request, abort

from .db import query, get_db

bp = Blueprint("catalog", __name__)

SORT_COLUMNS = {
    "name": "name",
    "price": "price_cents",
    "newest": "created_at",
}


@bp.get("/")
def index():
    sort = request.args.get("sort", "name")
    direction = "desc" if request.args.get("dir") == "desc" else "asc"
    column = SORT_COLUMNS.get(sort, "name")
    category = request.args.get("category")

    statement = (
        "SELECT id, sku, name, description, category, price_cents, stock, image_name "
        "FROM storefront.products"
    )
    params = []
    if category:
        statement += " WHERE category = %s"
        params.append(category)
    statement += f" ORDER BY {column} {'DESC' if direction == 'desc' else 'ASC'}"

    products = query(statement, params)

    featured = random.choice(products) if products else None

    categories = query(
        "SELECT DISTINCT category FROM storefront.products ORDER BY category"
    )
    return render_template(
        "index.html",
        products=products,
        categories=[c["category"] for c in categories],
        sort=sort,
        direction=direction,
        category=category,
        featured=featured,
    )


@bp.get("/product/<int:product_id>")
def product_detail(product_id):
    product = query(
        "SELECT * FROM storefront.products WHERE id = %s", (product_id,), one=True
    )
    if product is None:
        abort(404)
    return render_template("product.html", product=product)


@bp.get("/search")
def search():
    q = request.args.get("q", "").strip()
    products = []
    if q:
        db = get_db()
        with db.cursor() as cur:
            cur.execute(
                f"SELECT id, name, category, price_cents, image_name FROM storefront.products WHERE name ILIKE '%{q}%' OR description ILIKE '%{q}%' ORDER BY name"
            )
            products = cur.fetchall()
    return render_template("search.html", products=products, q=q)
