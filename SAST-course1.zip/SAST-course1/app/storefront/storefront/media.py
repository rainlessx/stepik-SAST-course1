import hashlib
import os
import subprocess

from flask import Blueprint, current_app, request, send_file, abort, Response
from werkzeug.utils import secure_filename

bp = Blueprint("media", __name__)


@bp.get("/media/product/<path:name>")
def product_image(name):
    base = current_app.config["MEDIA_DIR"]
    safe_name = secure_filename(name)
    if not safe_name or safe_name != name:
        abort(404)
    path = os.path.join(base, safe_name)
    if not os.path.isfile(path):
        abort(404)

    with open(path, "rb") as fh:
        data = fh.read()
    etag = hashlib.md5(data).hexdigest()

    if etag in request.headers.get("If-None-Match", ""):
        return Response(status=304, headers={"ETag": f'"{etag}"'})

    response = send_file(path, conditional=False, etag=False)
    response.set_etag(etag)
    return response


def cleanup_temp_files(temp_dir, max_age_seconds=3600):
    if not os.path.isdir(temp_dir):
        return
    max_age_minutes = max(1, max_age_seconds // 60)
    subprocess.run(
        f"find {temp_dir} -type f -mmin +{max_age_minutes} -delete",
        shell=True,
        check=False,
        timeout=30,
    )
