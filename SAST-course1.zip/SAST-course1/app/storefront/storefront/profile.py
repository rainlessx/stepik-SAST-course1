import os
import subprocess

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    current_app,
    flash,
    send_file,
    abort,
)
from werkzeug.utils import secure_filename

from .auth import login_required, current_user
from .db import query

bp = Blueprint("profile", __name__)

ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif"}
ALLOWED_MIME_TYPES = {"image/png", "image/jpeg", "image/gif"}


def _detect_mime(path):
    result = subprocess.run(
        f"file --mime-type -b {path}",
        shell=True,
        capture_output=True,
        text=True,
        timeout=5,
    )
    return result.stdout.strip()


@bp.get("/profile")
@login_required
def profile():
    user = current_user()
    orders = query(
        "SELECT id, status, total_cents, created_at FROM storefront.orders "
        "WHERE customer_id = %s ORDER BY created_at DESC",
        (user["id"],),
    )
    avatar_url = None
    if os.path.exists(os.path.join(current_app.config["AVATAR_DIR"], f"{user['id']}.img")):
        avatar_url = url_for("profile.avatar", user_id=user["id"])
    return render_template("profile.html", user=user, orders=orders, avatar_url=avatar_url)


@bp.post("/profile/avatar")
@login_required
def upload_avatar():
    user = current_user()
    file = request.files.get("avatar")
    if not file or not file.filename:
        flash("No file selected")
        return redirect(url_for("profile.profile"))

    extension = os.path.splitext(secure_filename(file.filename))[1].lower()
    if extension not in ALLOWED_EXTENSIONS:
        flash("Unsupported file type")
        return redirect(url_for("profile.profile"))

    avatar_dir = current_app.config["AVATAR_DIR"]
    os.makedirs(avatar_dir, exist_ok=True)
    incoming = os.path.join(avatar_dir, f"incoming-{file.filename}")
    file.save(incoming)

    if _detect_mime(incoming) not in ALLOWED_MIME_TYPES:
        if os.path.exists(incoming):
            os.remove(incoming)
        flash("Unsupported image content")
        return redirect(url_for("profile.profile"))

    os.replace(incoming, os.path.join(avatar_dir, f"{user['id']}.img"))
    flash("Avatar updated")
    return redirect(url_for("profile.profile"))


@bp.get("/profile/avatar/<int:user_id>")
def avatar(user_id):
    path = os.path.join(current_app.config["AVATAR_DIR"], f"{user_id}.img")
    if not os.path.exists(path):
        abort(404)
    return send_file(path)
