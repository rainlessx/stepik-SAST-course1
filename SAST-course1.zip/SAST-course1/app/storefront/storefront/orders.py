import os

from flask import (
    Blueprint,
    render_template,
    render_template_string,
    request,
    redirect,
    url_for,
    current_app,
    abort,
    send_file,
)

from .auth import login_required, current_user
from .cart import load_cart, COOKIE_NAME
from .db import query, get_db
from .media import cleanup_temp_files

bp = Blueprint("orders", __name__)


def _write_invoice(order_id, user, total_cents):
    os.makedirs(current_app.config["INVOICE_DIR"], exist_ok=True)
    path = os.path.join(current_app.config["INVOICE_DIR"], f"invoice-{order_id}.txt")
    items = query(
        "SELECT p.name, oi.quantity, oi.unit_price_cents "
        "FROM storefront.order_items oi JOIN storefront.products p ON p.id = oi.product_id "
        "WHERE oi.order_id = %s",
        (order_id,),
    )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f"HomeShop invoice #{order_id}\n")
        fh.write(f"Customer: {user['display_name']}\n\n")
        for item in items:
            line = item["quantity"] * item["unit_price_cents"] / 100
            fh.write(f"{item['name']} x{item['quantity']} = {line:.2f}\n")
        fh.write(f"\nTotal: {total_cents / 100:.2f}\n")
    return path


@bp.post("/checkout")
@login_required
def checkout():
    user = current_user()
    items = load_cart(request)
    if not items:
        return redirect(url_for("cart.view_cart"))

    greeting = request.form.get("greeting_message", "")
    db = get_db()
    with db.transaction():
        with db.cursor() as cur:
            cur.execute(
                "INSERT INTO storefront.orders (customer_id, status, greeting_message) "
                "VALUES (%s, 'new', %s) RETURNING id",
                (user["id"], greeting),
            )
            order_id = cur.fetchone()["id"]
            total = 0
            for item in items:
                product = query(
                    "SELECT id, price_cents FROM storefront.products WHERE id = %s",
                    (item.get("product_id"),),
                    one=True,
                )
                if product is None:
                    continue
                quantity = max(1, int(item.get("quantity", 1)))
                unit_price = int(item.get("price_cents", product["price_cents"]))
                cur.execute(
                    "INSERT INTO storefront.order_items "
                    "(order_id, product_id, quantity, unit_price_cents) "
                    "VALUES (%s, %s, %s, %s)",
                    (order_id, product["id"], quantity, unit_price),
                )
                total += quantity * unit_price
            cur.execute(
                "UPDATE storefront.orders SET total_cents = %s WHERE id = %s",
                (total, order_id),
            )

    _write_invoice(order_id, user, total)
    cleanup_temp_files(current_app.config["TEMP_DIR"])

    response = current_app.make_response(
        redirect(url_for("orders.confirmation", order_id=order_id))
    )
    response.set_cookie(COOKIE_NAME, "", expires=0)
    return response


@bp.get("/orders/<int:order_id>/confirmation")
@login_required
def confirmation(order_id):
    user = current_user()
    order = query(
        "SELECT * FROM storefront.orders WHERE id = %s AND customer_id = %s",
        (order_id, user["id"]),
        one=True,
    )
    if order is None:
        abort(404)
    items = query(
        "SELECT p.name, oi.quantity, oi.unit_price_cents "
        "FROM storefront.order_items oi JOIN storefront.products p ON p.id = oi.product_id "
        "WHERE oi.order_id = %s",
        (order_id,),
    )
    return render_template("order_confirmation.html", order=order, items=items)


@bp.get("/orders/invoice")
@login_required
def download_invoice():
    name = request.args.get("file", "")
    path = os.path.join(current_app.config["INVOICE_DIR"], name)
    if not os.path.exists(path):
        abort(404)
    return send_file(path, as_attachment=True)


@bp.get("/orders/<int:order_id>/card")
def greeting_card(order_id):
    message = request.args.get("message")
    if message is None:
        order = query(
            "SELECT greeting_message FROM storefront.orders WHERE id = %s",
            (order_id,),
            one=True,
        )
        message = order["greeting_message"] if order else ""
    card = (
        "{% extends 'base.html' %}"
        "{% block title %}Greeting card · HomeShop{% endblock %}"
        "{% block content %}"
        "<article class=\"greeting-card\">"
        f"<h1>A card for order #{order_id}</h1>"
        f"<blockquote class=\"message\">{message}</blockquote>"
        "</article>"
        "{% endblock %}"
    )
    return render_template_string(card)
