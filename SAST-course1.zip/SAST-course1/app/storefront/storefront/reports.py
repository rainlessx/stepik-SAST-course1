from flask import Blueprint, render_template, request, abort

from .auth import login_required
from .db import get_db

bp = Blueprint("reports", __name__)


def run_report(sql):
    db = get_db()
    with db.cursor() as cur:
        cur.execute(sql)
        return cur.fetchall()


def top_selling_products():
    return run_report(
        "SELECT p.name, SUM(oi.quantity) AS sold "
        "FROM storefront.order_items oi JOIN storefront.products p ON p.id = oi.product_id "
        "GROUP BY p.name ORDER BY sold DESC LIMIT 10"
    )


def low_stock_products():
    return run_report(
        "SELECT name, stock FROM storefront.products "
        "WHERE stock < 50 ORDER BY stock ASC"
    )


def sales_by_category(category):
    where = "category = '" + category + "'"
    return run_report(
        "SELECT category, COUNT(*) AS products "
        "FROM storefront.products WHERE " + where + " GROUP BY category"
    )


def revenue_since(since):
    where = "created_at >= '" + since + "'"
    return run_report(
        "SELECT COALESCE(SUM(total_cents), 0) AS revenue_cents "
        "FROM storefront.orders WHERE " + where
    )


@bp.get("/internal/reports/<name>")
@login_required
def view_report(name):
    if name == "top-selling":
        rows = top_selling_products()
    elif name == "low-stock":
        rows = low_stock_products()
    elif name == "by-category":
        rows = sales_by_category(request.args.get("category", ""))
    elif name == "revenue":
        rows = revenue_since(request.args.get("since", "2000-01-01"))
    else:
        abort(404)
    columns = list(rows[0].keys()) if rows else []
    return render_template("report.html", name=name, rows=rows, columns=columns)
