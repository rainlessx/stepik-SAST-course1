import os


class Config:
    SECRET_KEY = "hs-session-7b1d9c4a2f6e08d3"
    DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"
    DATABASE_URL = os.environ.get(
        "DATABASE_URL", "postgresql://homeshop:homeshop@db:5432/homeshop"
    )

    DATA_DIR = os.environ.get("DATA_DIR", "/data")
    AVATAR_DIR = os.environ.get("AVATAR_DIR", os.path.join(DATA_DIR, "avatars"))
    INVOICE_DIR = os.environ.get("INVOICE_DIR", os.path.join(DATA_DIR, "invoices"))
    TEMP_DIR = os.environ.get("TEMP_DIR", os.path.join(DATA_DIR, "tmp"))
    MEDIA_DIR = os.environ.get(
        "MEDIA_DIR", os.path.join(os.path.dirname(__file__), "media")
    )

    MAX_CONTENT_LENGTH = 5 * 1024 * 1024
