import os

from flask import Flask, jsonify

from .config import Config
from . import db


def create_app(config_object=Config):
    app = Flask(__name__)
    app.config.from_object(config_object)

    for key in ("AVATAR_DIR", "INVOICE_DIR", "TEMP_DIR"):
        os.makedirs(app.config[key], exist_ok=True)

    app.teardown_appcontext(db.close_db)

    from . import catalog, cart, auth, profile, orders, media, reports

    app.register_blueprint(catalog.bp)
    app.register_blueprint(cart.bp)
    app.register_blueprint(auth.bp)
    app.register_blueprint(profile.bp)
    app.register_blueprint(orders.bp)
    app.register_blueprint(media.bp)
    app.register_blueprint(reports.bp)

    @app.get("/healthz")
    def healthz():
        return jsonify(status="ok")

    @app.context_processor
    def inject_user():
        from .auth import current_user

        return {"current_user": current_user()}

    return app
