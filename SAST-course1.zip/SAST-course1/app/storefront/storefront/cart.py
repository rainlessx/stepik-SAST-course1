import base64
import pickle

from flask import Blueprint, request, redirect, url_for, render_template, make_response

from .db import query

bp = Blueprint("cart", __name__)

COOKIE_NAME = "cart"


def load_cart(req):
    raw = req.cookies.get(COOKIE_NAME)
    if not raw:
        return []
    try:
        data = pickle.loads(base64.b64decode(raw))
    except Exception:
        return []
    if not isinstance(data, list):
        return []
    return data


def dump_cart(items):
    return base64.b64encode(pickle.dumps(items)).decode("ascii")


def _cart_with_products(items):
    lines = []
    total = 0
    for item in items:
        product = query(
            "SELECT id, name, price_cents, image_name FROM storefront.products WHERE id = %s",
            (item.get("product_id"),),
            one=True,
        )
        if product is None:
            continue
        quantity = max(1, int(item.get("quantity", 1)))
        line_cents = quantity * product["price_cents"]
        total += line_cents
        lines.append({"product": product, "quantity": quantity, "line_cents": line_cents})
    return lines, total


@bp.get("/cart")
def view_cart():
    lines, total = _cart_with_products(load_cart(request))
    return render_template("cart.html", lines=lines, total=total)


@bp.post("/cart/add")
def add_to_cart():
    product_id = int(request.form["product_id"])
    quantity = max(1, int(request.form.get("quantity", 1)))
    items = load_cart(request)
    for item in items:
        if item.get("product_id") == product_id:
            item["quantity"] = int(item.get("quantity", 1)) + quantity
            break
    else:
        items.append({"product_id": product_id, "quantity": quantity})
    response = make_response(redirect(url_for("cart.view_cart")))
    response.set_cookie(COOKIE_NAME, dump_cart(items), httponly=True, samesite="Lax")
    return response


@bp.post("/cart/remove")
def remove_from_cart():
    product_id = int(request.form["product_id"])
    items = [i for i in load_cart(request) if i.get("product_id") != product_id]
    response = make_response(redirect(url_for("cart.view_cart")))
    response.set_cookie(COOKIE_NAME, dump_cart(items), httponly=True, samesite="Lax")
    return response
