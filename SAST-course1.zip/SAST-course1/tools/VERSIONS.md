# Pinned scanner versions

Every scanner, image and rule set used by `make scan` / `make scan-sonar` is
pinned so results stay reproducible for the lifetime of the course. The
machine-readable copy consumed by the scripts is `tools/versions.env`; this file
is the human-readable record and must be kept in sync with it.

## Scanner engines

| Scanner | Version | How it runs | Image / pin |
|---------|---------|-------------|-------------|
| Semgrep | 1.181.0 | registry image | `semgrep/semgrep:1.181.0@sha256:81474464c1f07483ba0682a44787fd93c91397419762a04abe2bafaae396304b` |
| OpenGrep | 1.31.0 | locally built (`tools/opengrep/Dockerfile`) | base `python:3.12-slim@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1`; release binary `opengrep_manylinux_x86` v1.31.0, SHA-256 `dbbe3c2058dbe600c449a8ba22ea79a1643a6660658400090d0323a8d0d31147` |
| Bandit | 1.9.4 (+ bandit-sarif-formatter 1.1.1) | locally built (`tools/bandit/Dockerfile`) | base `python:3.12-slim@sha256:a6e34c598f2467ed0e9a8d349809fcd8b5c603269512df273a0bb1784edc11b1`; `pip install bandit==1.9.4 bandit-sarif-formatter==1.1.1` |
| SpotBugs + FindSecBugs | spotbugs-maven-plugin 4.10.5.0 (SpotBugs core 4.10.5), findsecbugs-plugin 1.14.0 | Maven `sast` profile in the pinned Maven image | `maven:3.9.16-eclipse-temurin-21@sha256:99e61abcff91a9b1333463bd8451fb18495d6eba9250ac66a338b518f8278320` |
| SonarQube (optional) | 26.10.0.133078 Community | compose `sonar` profile | `sonarqube:26.10.0.133078-community@sha256:2e378f7852b67d43507d3d383ee8fb5a522b8b0f920be9803f74f72952fce8f1` |
| SonarScanner CLI (optional) | 12.2.0.4256 | `tools/sonar/analyze.sh` | `sonarsource/sonar-scanner-cli:12.2.0.4256_8.1.0@sha256:a3f4215076706c95a17a68c19322ee916e40a3acd081a8c1a1e839e0194afa57` |

Notes on "tag + digest":

- Registry images (Semgrep, Maven, SonarQube, SonarScanner) are pinned by both
  tag and content digest.
- The OpenGrep and Bandit images are built locally because neither tool ships a
  version-pinned official image (OpenGrep publishes only standalone binaries;
  the Bandit GHCR image has only a moving `latest`). Their reproducibility comes
  from a **digest-pinned base image** plus a **pinned tool version** — the
  OpenGrep binary additionally verified by SHA-256 at build time.

## Rule set

| Field | Value |
|-------|-------|
| Set | `opengrep/opengrep-rules`, Python + Java rules only |
| Repo | https://github.com/opengrep/opengrep-rules.git |
| Commit | `f1d2b562b414783763fd02a6ed2736eaed622efa` (2025-01-26) |
| Location | `tools/rules/opengrep-rules/` — **downloaded, git-ignored, not redistributed** |
| Fetched by | `tools/fetch-rules.sh` (run automatically by `make scan` when missing) |
| Licence | LGPL-2.1 with the "Commons Clause" condition |

Reproducibility: `fetch-rules.sh` checks out the exact commit above and verifies
the resulting `HEAD` hash, so the rule content is pinned even though it is not
stored in this repository. The download happens once; after that nothing is
fetched from the network at scan time.

### Which Semgrep rule set, and why (licensing)

The upstream Semgrep rule repository changed its licence, so the choice matters:

- **`semgrep/semgrep-rules` — current `HEAD`: not usable.** On 2024-12-13 (commit
  `2a662d5`) the repository was relicensed from "LGPL-2.1 + Commons Clause" to the
  proprietary **Semgrep Rules License v1.0**, which limits use to the Semgrep
  platform.

- **Chosen: `opengrep/opengrep-rules` (LGPL-2.1 + Commons Clause).** OpenGrep is
  the community fork created from the last pre-relicense state of
  `semgrep-rules`, so it keeps the original **LGPL-2.1** terms (with the Commons
  Clause rider). It is the natural match for the OpenGrep engine, and the rule
  format is identical to Semgrep's, so a single downloaded copy drives both
  Semgrep and OpenGrep.

- **Why we download instead of vendoring.** The Commons Clause rider forbids
  *selling* a product or service "whose value derives, entirely or substantially,
  from the functionality of the Software." To avoid redistributing the rules with
  a paid course at all, this repository does not store them: `make scan` fetches
  them from upstream under their own licence, and they stay in the git-ignored
  `tools/rules/`. The vendored `LICENSE` that `fetch-rules.sh` copies next to the
  rules keeps the upstream notice intact for the local copy.

## Outputs

`make scan` writes to `out/` (git-ignored):

| Scanner | JSON | SARIF | Other |
|---------|------|-------|-------|
| Semgrep | `out/semgrep.json` | `out/semgrep.sarif` | |
| OpenGrep | `out/opengrep.json` | `out/opengrep.sarif` | |
| Bandit | `out/bandit.json` | `out/bandit.sarif` | |
| SpotBugs + FindSecBugs | — (SARIF is the JSON form) | `out/spotbugs.sarif` | `out/spotbugs.xml` |
