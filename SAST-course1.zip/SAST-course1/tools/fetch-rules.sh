#!/usr/bin/env bash
#
# Fetch the Semgrep/OpenGrep rule set used by `make scan`.
#
# The rules are LGPL-2.1 with a Commons Clause rider, so this repository does not
# redistribute them. They are downloaded from the upstream OpenGrep rules
# repository at a pinned commit into tools/rules/ (git-ignored). `make scan`
# runs this automatically when the rules are missing; the pinned commit hash is
# verified after checkout so the rule content is reproducible.
#
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=tools/versions.env
source "$ROOT/tools/versions.env"

DEST="$ROOT/$RULES_DIR"          # tools/rules/opengrep-rules
STAMP="$DEST/.commit"

if [ -f "$STAMP" ] && [ "$(cat "$STAMP")" = "$OPENGREP_RULES_COMMIT" ]; then
  echo "rules already present at $OPENGREP_RULES_COMMIT"
  exit 0
fi

echo "==> fetching rules $OPENGREP_RULES_COMMIT from $OPENGREP_RULES_REPO"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

git clone --quiet --filter=blob:none --no-checkout "$OPENGREP_RULES_REPO" "$tmp/repo"
git -C "$tmp/repo" sparse-checkout init --cone
git -C "$tmp/repo" sparse-checkout set python java
git -C "$tmp/repo" -c advice.detachedHead=false checkout --quiet "$OPENGREP_RULES_COMMIT"

got="$(git -C "$tmp/repo" rev-parse HEAD)"
if [ "$got" != "$OPENGREP_RULES_COMMIT" ]; then
  echo "commit mismatch: got $got, expected $OPENGREP_RULES_COMMIT" >&2
  exit 1
fi

rm -rf "$DEST"
mkdir -p "$DEST"
cp "$tmp/repo/LICENSE" "$DEST/LICENSE"
# Only the Python/Java rule definitions; skip test fixtures and example targets.
( cd "$tmp/repo" && find python java \( -name '*.yaml' -o -name '*.yml' \) \
    ! -name '*.test.yaml' ! -name '*.test.yml' -print0 \
  | cpio -0 -pdm --quiet "$DEST" )
echo "$OPENGREP_RULES_COMMIT" > "$STAMP"

echo "==> $(find "$DEST" -name '*.y*ml' | wc -l) rule files in $RULES_DIR (licence: $RULES_DIR/LICENSE)"
