#!/usr/bin/env bash
#
# Run the pinned SAST scanners over the HomeShop sources and collect machine
# readable reports under out/. Invoked by `make scan`.
#
# Everything runs in containers with fixed versions. Rule sets are vendored
# under tools/rules/ and never fetched from the network at scan time. The two
# locally built scanner images (OpenGrep, Bandit) are built on first use.
#
# Each scanner is isolated: a failure or a non-zero "findings present" exit
# code from one does not stop the others. A short summary is printed at the end.

set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
# shellcheck source=tools/versions.env
source "$ROOT/tools/versions.env"

OUT="$ROOT/out"
mkdir -p "$OUT"

log() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }

ensure_image() {
  # ensure_image <image-tag> <dockerfile-dir>
  if ! docker image inspect "$1" >/dev/null 2>&1; then
    log "building $1"
    docker build -t "$1" "$ROOT/$2"
  fi
}

ensure_rules() {
  # Rules are not shipped with the repo; download them on first use.
  if [ ! -d "$ROOT/$RULES_DIR/python" ] || [ ! -d "$ROOT/$RULES_DIR/java" ]; then
    bash "$ROOT/tools/fetch-rules.sh"
  fi
}

PY_RULES="/src/$RULES_DIR/python"
JAVA_RULES="/src/$RULES_DIR/java"

# ---------------------------------------------------------------- Semgrep ----
run_semgrep() {
  ensure_rules
  log "Semgrep ($SEMGREP_IMAGE)"
  local common=(scan --disable-version-check --metrics=off --quiet
    --config "$PY_RULES" --config "$JAVA_RULES"
    --exclude target --exclude '__pycache__' /src/app)
  docker run --rm -e SEMGREP_ENABLE_VERSION_CHECK=0 -v "$ROOT:/src:ro" \
    "$SEMGREP_IMAGE" semgrep "${common[@]}" --json  > "$OUT/semgrep.json"  || true
  docker run --rm -e SEMGREP_ENABLE_VERSION_CHECK=0 -v "$ROOT:/src:ro" \
    "$SEMGREP_IMAGE" semgrep "${common[@]}" --sarif > "$OUT/semgrep.sarif" || true
}

# --------------------------------------------------------------- OpenGrep ----
run_opengrep() {
  ensure_rules
  ensure_image "$OPENGREP_IMAGE" "$OPENGREP_DOCKERFILE_DIR"
  log "OpenGrep ($OPENGREP_IMAGE)"
  local common=(scan --disable-version-check
    --config "$PY_RULES" --config "$JAVA_RULES"
    --exclude target --exclude '__pycache__' /src/app)
  docker run --rm -v "$ROOT:/src:ro" \
    "$OPENGREP_IMAGE" "${common[@]}" --json  > "$OUT/opengrep.json"  || true
  docker run --rm -v "$ROOT:/src:ro" \
    "$OPENGREP_IMAGE" "${common[@]}" --sarif > "$OUT/opengrep.sarif" || true
}

# ----------------------------------------------------------------- Bandit ----
run_bandit() {
  ensure_image "$BANDIT_IMAGE" "$BANDIT_DOCKERFILE_DIR"
  log "Bandit ($BANDIT_IMAGE)"
  local common=(-r /src/app/storefront -x /src/app/storefront/tests)
  docker run --rm -v "$ROOT:/src:ro" \
    "$BANDIT_IMAGE" "${common[@]}" -f json  > "$OUT/bandit.json"  || true
  docker run --rm -v "$ROOT:/src:ro" \
    "$BANDIT_IMAGE" "${common[@]}" -f sarif > "$OUT/bandit.sarif" || true
}

# ------------------------------------------------- SpotBugs + FindSecBugs ----
run_spotbugs() {
  log "SpotBugs + FindSecBugs ($MAVEN_IMAGE)"
  # The project must be compiled before analysis; the `sast` profile wires the
  # SpotBugs plugin with the FindSecBugs detector and emits SARIF + XML.
  docker run --rm \
    -v "$M2_VOLUME:/root/.m2" \
    -v "$ROOT/app/backoffice:/workspace" \
    -w /workspace \
    "$MAVEN_IMAGE" \
    mvn -B -ntp -P sast -DskipTests clean compile spotbugs:spotbugs || true

  local target="$ROOT/app/backoffice/target"
  [ -f "$target/spotbugsSarif.json" ] && cp "$target/spotbugsSarif.json" "$OUT/spotbugs.sarif"
  [ -f "$target/spotbugsXml.xml" ]    && cp "$target/spotbugsXml.xml"    "$OUT/spotbugs.xml"
}

# ---------------------------------------------------------------- summary ----
summary() {
  log "Reports written to out/ — findings (rule, file, line):"
  python3 - "$OUT" <<'PY'
import glob, json, os, re, sys, xml.etree.ElementTree as ET
out = sys.argv[1]
JAVA_SRC = "app/backoffice/src/main/java/"

def rel(p): return re.sub(r"^/src/", "", p or "")

def semgrep_like(p):
    rows = set()
    for r in json.load(open(p)).get("results", []):
        rows.add((rel(r["path"]), r["start"]["line"], r["check_id"].split(".")[-1]))
    return rows

def bandit(p):
    rows = set()
    for r in json.load(open(p)).get("results", []):
        rows.add((rel(r["filename"]), r["line_number"], r["test_id"]))
    return rows

def spotbugs(p):
    rows = set()
    for b in ET.parse(p).getroot().findall(".//BugInstance"):
        sp = ln = None
        for s in b.findall(".//SourceLine"):
            if s.get("sourcepath"): sp, ln = s.get("sourcepath"), s.get("start"); break
        rows.add(((JAVA_SRC + sp) if sp else "?", int(ln) if ln else 0, b.get("type")))
    return rows

readers = {"semgrep.json": semgrep_like, "opengrep.json": semgrep_like,
           "bandit.json": bandit, "spotbugs.xml": spotbugs}
for name in ("semgrep.json", "opengrep.json", "bandit.json", "spotbugs.xml"):
    p = os.path.join(out, name)
    tool = name.split(".")[0]
    if not os.path.exists(p):
        print(f"\n  {tool}: (not produced)"); continue
    try:
        rows = sorted(readers[name](p), key=lambda x: (x[0], x[1], x[2]))
    except Exception as e:
        print(f"\n  {tool}: (unreadable: {e})"); continue
    print(f"\n  {tool}: {len(rows)} findings")
    for f, ln, rule in rows:
        print(f"    {rule:42} {f}:{ln}")
print("\n  SARIF:", ", ".join(sorted(os.path.basename(x) for x in glob.glob(os.path.join(out, "*.sarif")))))
PY
}

TOOLS="${1:-all}"
case "$TOOLS" in
  all)      run_semgrep; run_opengrep; run_bandit; run_spotbugs ;;
  semgrep)  run_semgrep ;;
  opengrep) run_opengrep ;;
  bandit)   run_bandit ;;
  spotbugs) run_spotbugs ;;
  *) echo "usage: scan.sh [all|semgrep|opengrep|bandit|spotbugs]" >&2; exit 2 ;;
esac
summary
