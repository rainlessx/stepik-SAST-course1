# Сканеры

`make scan` запускает зафиксированные SAST-сканеры (Semgrep, OpenGrep, Bandit,
SpotBugs + FindSecBugs) в Docker и складывает отчёты в `out/` — JSON и, где есть,
SARIF. Точные версии и образы перечислены в [`VERSIONS.md`](VERSIONS.md).
SonarQube Community — необязательный тяжёлый профиль, см. [`sonar/`](sonar/).

Правила для Semgrep/OpenGrep скачиваются при первом запуске из репозитория
OpenGrep (`opengrep/opengrep-rules`) под его собственной лицензией и не входят в
этот репозиторий (скрипт `tools/fetch-rules.sh`, каталог `tools/rules/`).
