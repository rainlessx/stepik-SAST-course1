# SonarQube (optional)

SonarQube Community is the one heavy scanner on the stand, so it is kept out of
`make scan` and the default compose stack. It lives in the `sonar` compose
profile and is driven by `tools/sonar/analyze.sh`.

## Run

```sh
make scan-sonar          # starts the server, waits, analyses both services
```

or manually:

```sh
docker compose --profile sonar up -d sonarqube
./tools/sonar/analyze.sh
docker compose --profile sonar down     # stop it when done
```

Dashboard: http://127.0.0.1:9000 (default login `admin` / `admin`).

## Requirements

- ~2 GB RAM for the SonarQube container alone (on top of the rest of the stack).
- The Elasticsearch bundled in SonarQube needs a raised `vm.max_map_count` on the
  host:

  ```sh
  sudo sysctl -w vm.max_map_count=262144
  ```

  The container also disables the bootstrap checks (`SONAR_ES_BOOTSTRAP_CHECKS_DISABLE`)
  so it still starts on a stricter host, but the sysctl above is recommended.

## Token

`analyze.sh` tries to create an analysis token automatically using the default
admin credentials. If SonarQube has forced an admin password change, create a
token in the UI (My Account > Security) and re-run:

```sh
SONAR_TOKEN=squ_xxx ./tools/sonar/analyze.sh
```

Image versions are pinned in `tools/VERSIONS.md` and `compose.yaml`.
