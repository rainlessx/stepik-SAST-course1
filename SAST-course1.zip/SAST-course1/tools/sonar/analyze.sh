#!/usr/bin/env bash
#
# Optional, heavy: analyse the stand with a local SonarQube Community server.
#
# This is deliberately kept out of `make scan`: SonarQube needs ~2 GB of RAM on
# its own and a few minutes to start. It lives in the `sonar` compose profile so
# the default stack stays light.
#
# Steps:
#   1. start the SonarQube container (compose profile `sonar`)
#   2. wait for it to report status UP
#   3. obtain an analysis token (best effort; manual fallback documented below)
#   4. compile the back office (SonarQube's Java analysis needs the .class files)
#   5. run sonar-scanner-cli over both services
#
# The scanner image is pinned in tools/VERSIONS.md. If automatic token creation
# fails (SonarQube may force an admin password change on first boot), create a
# token in the UI at http://127.0.0.1:9000 (My Account > Security) and re-run:
#
#     SONAR_TOKEN=squ_xxx ./tools/sonar/analyze.sh
#
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
source "$ROOT/tools/versions.env"

COMPOSE="${COMPOSE:-docker compose}"
SONAR_URL="http://127.0.0.1:9000"

echo "==> starting SonarQube (compose profile 'sonar')"
$COMPOSE --profile sonar up -d sonarqube

echo "==> waiting for SonarQube to come up (can take a few minutes)"
for _ in $(seq 1 60); do
  status="$(curl -fsS "$SONAR_URL/api/system/status" 2>/dev/null \
            | python3 -c "import sys,json;print(json.load(sys.stdin).get('status',''))" 2>/dev/null)"
  echo "    status: ${status:-starting}"
  [ "$status" = "UP" ] && break
  sleep 10
done
[ "${status:-}" = "UP" ] || { echo "SonarQube did not become ready; check '$COMPOSE --profile sonar logs sonarqube'"; exit 1; }

# --- token ----------------------------------------------------------------
if [ -z "${SONAR_TOKEN:-}" ]; then
  echo "==> obtaining analysis token"
  # Best effort: works while the admin account still has default credentials.
  SONAR_TOKEN="$(curl -fsS -u admin:admin -X POST \
      "$SONAR_URL/api/user_tokens/generate?name=homeshop-$(date +%s)" 2>/dev/null \
      | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))" 2>/dev/null)"
fi
if [ -z "${SONAR_TOKEN:-}" ]; then
  echo "Could not create a token automatically (admin password was probably changed)."
  echo "Create one in the UI at $SONAR_URL and re-run with SONAR_TOKEN=... set."
  exit 1
fi

# --- compile back office (needed for Java analysis) -----------------------
echo "==> compiling back office for Java analysis"
docker run --rm \
  -v "$M2_VOLUME:/root/.m2" \
  -v "$ROOT/app/backoffice:/workspace" \
  -w /workspace \
  "$MAVEN_IMAGE" mvn -B -ntp -DskipTests clean compile

# --- run scanner ----------------------------------------------------------
echo "==> running sonar-scanner-cli"
docker run --rm --network host \
  -e SONAR_HOST_URL="$SONAR_URL" \
  -e SONAR_TOKEN="$SONAR_TOKEN" \
  -v "$ROOT:/usr/src" \
  "$SONAR_SCANNER_IMAGE" \
  -Dproject.settings=tools/sonar/sonar-project.properties

echo "==> done. Dashboard: $SONAR_URL/dashboard?id=homeshop"
