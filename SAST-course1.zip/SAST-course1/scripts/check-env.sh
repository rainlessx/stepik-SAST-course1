#!/usr/bin/env bash
#
# Course 0 — environment check for the HomeShop stand.
# Works on Linux, macOS and Windows (inside WSL2). No root required.
#
# Runs every check, prints a clear message for each, and prints the token
# LAB00-ENV-READY only if everything passed.
#
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

TOKEN="LAB00-ENV-READY"
FAIL=0
WARN=0
ok()   { printf '  [ ok ] %s\n' "$1"; }
bad()  { printf '  [FAIL] %s\n' "$1"; FAIL=1; }   # блокирует запуск стенда
warn() { printf '  [warn] %s\n' "$1"; WARN=1; }   # не мешает запуску, но стоит учесть
hint() { printf '         ↳ %s\n' "$1"; }

# Пороги памяти/диска — из реального замера стенда (пик ~0.8 ГБ ОЗУ при
# make up + make scan; образы Docker ~5 ГБ) с запасом.
MEM_MIN_MB=2048
DISK_MIN_MB=6144

# Read a port from .env (if present), else .env.example, else the default.
port_of() {
  local name="$1" def="$2" f v
  for f in .env .env.example; do
    [ -f "$f" ] || continue
    v="$(grep -E "^${name}=" "$f" | tail -1 | cut -d= -f2 | tr -d ' "'"'"'')"
    [ -n "$v" ] && { echo "$v"; return; }
  done
  echo "$def"
}

echo "== Проверка окружения HomeShop =="

# 1. Docker + daemon ----------------------------------------------------------
if command -v docker >/dev/null 2>&1; then
  if docker info >/dev/null 2>&1; then
    ok "Docker установлен и демон запущен"
  else
    bad "Docker установлен, но демон не отвечает"
    hint "Запустите Docker Desktop / сервис dockerd и повторите."
  fi
else
  bad "Docker не найден"
  hint "Установите Docker: https://docs.docker.com/get-docker/"
fi

# 2. Docker Compose v2 --------------------------------------------------------
if docker compose version >/dev/null 2>&1; then
  ok "Docker Compose v2 ($(docker compose version | head -1))"
elif command -v docker-compose >/dev/null 2>&1; then
  bad "Найден старый docker-compose (v1), нужен плагин 'docker compose' (v2)"
  hint "Поставьте плагин compose v2. Если нет пакета — положите бинарник в"
  hint "~/.docker/cli-plugins/docker-compose (или /usr/libexec/docker/cli-plugins/) и chmod +x."
else
  bad "Docker Compose v2 не найден (команда 'docker compose')"
  hint "Установите плагин compose: https://docs.docker.com/compose/install/"
fi

# 3. Memory >= 4 GB -----------------------------------------------------------
mem_mb=-1
if [ -r /proc/meminfo ]; then
  mem_mb="$(awk '/^MemAvailable:/ {print int($2/1024)}' /proc/meminfo)"
elif command -v sysctl >/dev/null 2>&1 && sysctl -n hw.memsize >/dev/null 2>&1; then
  mem_mb=$(( $(sysctl -n hw.memsize) / 1024 / 1024 ))   # macOS: всего физической
fi
if [ "$mem_mb" -lt 0 ] 2>/dev/null; then
  warn "Не удалось измерить память — проверьте вручную (рекомендуется ≥ ${MEM_MIN_MB} МБ свободно)"
elif [ "$mem_mb" -ge "$MEM_MIN_MB" ]; then
  ok "Память: ${mem_mb} МБ доступно (рекомендуется ≥ ${MEM_MIN_MB})"
else
  warn "Памяти меньше рекомендуемого: ${mem_mb} МБ (рекомендуется ≥ ${MEM_MIN_MB})"
  hint "Стенду хватает ~0.8 ГБ, но с запасом лучше закрыть лишнее / поднять RAM Docker/WSL2."
fi

# 4. Disk >= 5 GB -------------------------------------------------------------
disk_mb="$(df -Pk . | awk 'NR==2 {print int($4/1024)}')"
if [ "${disk_mb:-0}" -ge "$DISK_MIN_MB" ]; then
  ok "Диск: ${disk_mb} МБ свободно (рекомендуется ≥ ${DISK_MIN_MB})"
else
  warn "Места на диске меньше рекомендуемого: ${disk_mb:-?} МБ (рекомендуется ≥ ${DISK_MIN_MB})"
  hint "Образы Docker занимают ~5 ГБ; освободите место, иначе сборка может не влезть."
fi

# 5. Stand ports free ---------------------------------------------------------
port_free() {  # 0 = свободен
  if (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; then exec 3>&- 3<&-; return 1; fi
  return 0
}
for spec in "STOREFRONT_PORT:8000:витрина" "BACKOFFICE_PORT:8081:бэкофис" "DB_PORT:5432:база данных"; do
  name="${spec%%:*}"; rest="${spec#*:}"; def="${rest%%:*}"; label="${rest#*:}"
  p="$(port_of "$name" "$def")"
  if port_free "$p"; then
    ok "Порт $p свободен ($label)"
  elif docker compose ps 2>/dev/null | grep -q "127\.0\.0\.1:${p}->"; then
    ok "Порт $p занят самим стендом — он уже запущен ($label)"
  else
    bad "Порт $p занят другим процессом ($label)"
    hint "Скопируйте .env.example в .env и поменяйте $name на свободный порт (или остановите процесс)."
  fi
done

# 6. Proxy: localhost must bypass it -----------------------------------------
if [ -n "${HTTP_PROXY:-}${HTTPS_PROXY:-}${http_proxy:-}${https_proxy:-}" ]; then
  np="${NO_PROXY:-}${no_proxy:-}"
  if printf '%s' "$np" | grep -q '127.0.0.1' && printf '%s' "$np" | grep -q 'localhost'; then
    ok "Прокси задан, и 127.0.0.1/localhost в NO_PROXY — запросы к стенду не пойдут через прокси"
  else
    warn "Задан HTTP(S)_PROXY, но 127.0.0.1/localhost нет в NO_PROXY"
    hint "export NO_PROXY=\"localhost,127.0.0.1,\$NO_PROXY\" (и no_proxy) — иначе запросы к стенду могут ломаться."
  fi
else
  ok "HTTP(S)-прокси не задан"
fi

# 7. Can pull a base image ----------------------------------------------------
if docker info >/dev/null 2>&1; then
  if docker pull hello-world >/dev/null 2>&1; then
    ok "Docker может скачивать образы (проверено на hello-world)"
    docker rmi hello-world >/dev/null 2>&1 || true
  else
    bad "Не удалось скачать тестовый образ hello-world"
    hint "Проверьте интернет/прокси и доступ к Docker Hub."
  fi
else
  bad "Пропущена проверка загрузки образов (демон недоступен)"
fi

echo
if [ "$FAIL" -eq 0 ]; then
  if [ "$WARN" -ne 0 ]; then
    echo "Критичных проблем нет (есть предупреждения [warn] — стенд запустится, но учтите их)."
  else
    echo "Всё готово."
  fi
  echo "Токен для Stepik:"
  echo "$TOKEN"
  exit 0
fi
echo "Есть блокирующие проблемы — исправьте отмеченные [FAIL] и запустите скрипт снова."
exit 1
